<template>
  <div>
    <h1>Gestión de Empleados</h1>
    <AddEmployee />
    <EmployeeList />
  </div>
</template>

<script setup>
import AddEmployee from '@/components/AddEmployee.vue';
import EmployeeList from '@/components/EmployeeList.vue';
</script>

