<template>
  <div>
    <h1>Bienvenido a la Gestión de Empleados</h1>
    <EmployeeStats />
  </div>
</template>

<script setup>
import EmployeeStats from '@/components/EmployeeStats.vue';
</script>
