<template>
    <div>
      <h2>Estadísticas</h2>
      <p>Total de empleados: {{ store.totalEmployees }}</p>
      <p>Salario promedio: ${{ store.salaryAverage }}</p>
      <p>Empleados por departamento:</p>
      <ul>
        <li v-for="(count, dept) in store.employeesByDepartment" :key="dept">
          {{ dept }}: {{ count }} empleados
        </li>
      </ul>
    </div>
  </template>
  
  <script setup>
  import { useEmployeeStore } from '@/store/employeeStore';
  const store = useEmployeeStore();
  </script>
  
<style scoped>
    .stats {
    padding: 20px;
    background-color: #eef;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
</style>