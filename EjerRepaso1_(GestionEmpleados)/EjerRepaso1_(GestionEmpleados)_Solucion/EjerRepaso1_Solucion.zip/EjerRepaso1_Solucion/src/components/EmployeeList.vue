<template>
    <div>
      <h2>Lista de Empleados</h2>
      <input v-model="filter" placeholder="Filtrar por departamento" />
      <ul>
        <li v-for="employee in filteredEmployees" :key="employee.id">
          {{ employee.name }} - {{ employee.department }} - ${{ employee.salary }}
        </li>
      </ul>
    </div>
  </template>
  
  <script setup>
  import { ref, computed } from 'vue';
  import { useEmployeeStore } from '@/store/employeeStore';
  
  const store = useEmployeeStore();
  const filter = ref('');
  
  const filteredEmployees = computed(() => {
    return store.employees.filter(emp =>
      emp.department.toLowerCase().includes(filter.value.toLowerCase())
    );
  });
  </script>

<style scoped>
    .employee-list {
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .input {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    }
    .employee-item {
    padding: 8px;
    border-bottom: 1px solid #ddd;
    }
</style>
  