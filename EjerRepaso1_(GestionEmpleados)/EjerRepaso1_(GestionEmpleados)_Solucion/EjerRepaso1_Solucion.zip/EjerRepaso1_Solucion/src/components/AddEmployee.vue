<template>
    <div>
      <h2>Agregar Empleado</h2>
      <form @submit.prevent="addNewEmployee">
        <input v-model="name" placeholder="Nombre" required />
        <input v-model="department" placeholder="Departamento" required />
        <input v-model.number="salary" placeholder="Salario" required />
        <button type="submit">Agregar</button>
      </form>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import { useEmployeeStore } from '@/store/employeeStore';
  
  const store = useEmployeeStore();
  const name = ref('');
  const department = ref('');
  const salary = ref(0);
  
  const addNewEmployee = () => {
    store.addEmployee({ id: Date.now(), name: name.value, department: department.value, salary: salary.value });
    name.value = '';
    department.value = '';
    salary.value = 0;
  };
  </script>
  
 <style scoped>
    .add-employee {
        padding: 20px;
        background-color: #f0f0f0;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .input {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .button {
        background-color: #007bff;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .button:hover {
        background-color: #0056b3;
    }
 </style> 