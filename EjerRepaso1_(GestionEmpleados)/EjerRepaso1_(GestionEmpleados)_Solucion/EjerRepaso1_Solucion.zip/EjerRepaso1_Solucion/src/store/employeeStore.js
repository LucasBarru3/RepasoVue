import { defineStore } from 'pinia';
import employeesData from '@/assets/Empleados.json';

export const useEmployeeStore = defineStore('employee', {
  state: () => ({
    employees: [...employeesData]
  }),
  getters: {
    totalEmployees: (state) => state.employees.length,
    salaryAverage: (state) => {
      if (state.employees.length === 0) return 0;
      return (
        state.employees.reduce((sum, emp) => sum + emp.salary, 0) /
        state.employees.length
      ).toFixed(2);
    },
    employeesByDepartment: (state) => {
      return state.employees.reduce((acc, emp) => {
        acc[emp.department] = (acc[emp.department] || 0) + 1;
        return acc;
      }, {});
    }
  },
  actions: {
    addEmployee(employee) {
      this.employees.push(employee);
    }
  }
});