<template>
  <div id="app">
    <nav>
      <router-link to="/">Inicio</router-link>
      <router-link to="/employees">Empleados</router-link>
    </nav>
    <router-view />
  </div>
</template>

<script setup>
</script>

<style scoped>
nav {
  display: flex;
  gap: 20px;
  padding: 10px;
  background-color: #f8f8f8;
  border-bottom: 2px solid #ddd;
}

nav a {
  text-decoration: none;
  color: #333;
  font-weight: bold;
}

nav a.router-link-exact-active {
  color: #007bff;
}
</style>
