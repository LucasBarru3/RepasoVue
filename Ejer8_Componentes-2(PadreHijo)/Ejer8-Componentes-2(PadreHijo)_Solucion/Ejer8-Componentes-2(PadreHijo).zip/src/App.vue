

<template>
  <h1>COMPONENTES PADRE HIJO</h1>
  <PostListComponent/>
  
</template>

<script setup>
  //8-Comunicacion entre Componentes
  //8.1-Comunicacion Padre-Hijo => Props
  import PostListComponent from './components/PostListComponent.vue'
</script>