## **Ejercicio: Componentes comunicación Padre-Hijo**

### **Descripción**

Crea una aplicación web sencilla que utilice dos componentes y envíe información entre el componente padre y el hijo. Se trata de simular la carga e varios Post, con información que se envía al componente hijo PostDetails 

**Funcionamiento**

1.  Al inicio en App.vue cargaremos el componente PostList
2. Este componente padre PostList, tendrá declarada un array de  5 posts. Además llamará a el componente PostDetails que se cargará 5 veces. Cada uno de los componentes hijo se cargará con la información que está guardada en el array de objetos.

