<template>
    <h1>PÁGINA PARA VER UN LISTADO DE PRODUCTOS</h1>
</template>