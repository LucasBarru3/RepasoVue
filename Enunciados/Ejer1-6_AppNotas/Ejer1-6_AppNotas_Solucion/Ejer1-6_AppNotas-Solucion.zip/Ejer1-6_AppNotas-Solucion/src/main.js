
import { createApp } from 'vue'
import App from './App-5.vue'

createApp(App).mount('#app')
