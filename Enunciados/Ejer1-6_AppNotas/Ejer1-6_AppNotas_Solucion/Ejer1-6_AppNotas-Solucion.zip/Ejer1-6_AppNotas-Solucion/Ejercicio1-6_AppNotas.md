### Ejercicio: Crear una Aplicación de Notas

Diseñar una aplicación simple de notas donde los usuarios puedan agregar, editar y eliminar notas.

**Acciones a realizar**
    -   Agregar una nueva nota.
    -   Editar una nota existente.
    -   Eliminar una nota.

    