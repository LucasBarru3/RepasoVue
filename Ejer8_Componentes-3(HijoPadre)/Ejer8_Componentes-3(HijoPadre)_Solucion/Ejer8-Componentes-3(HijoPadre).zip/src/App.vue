<script setup>
import ListarTareas from './components/ListarTareas.vue';

</script>

<template>
  <h1>GESTION DE TAREAS</h1>
  <h2>USO DE COMPONENTES Y ENVIO DE LA TAREA DESDE EL HIJO AL PADRE</h2>
  <ListarTareas></ListarTareas>
</template>

